<?php
defined('BASEPATH') or exit('No direct script access allowed');

//   设置Broker服务器列表    setMetadataBrokerList
$kafkaSet["BrokerHostPort"] = '172.0.71.54:9092';
