<?php
defined('BASEPATH') or exit('No direct script access allowed');

/**
 * Kafka PHP client library
 */
class KafkaLib
{
    protected static $producerConfig = null;
    protected static $consumerConfig = null;
    /**
     * 构造函数。
     */
    public function __construct()
    {
        $this->ctl = &get_instance();
    }

    /**
     * 初始kafka 生产消息配置。
     * @return [type] [description]
     */
    protected static function initProducerConfig(): void
    {
        if (empty(static::$producerConfig)) {
            try {
                if (empty($kafkaSet)) {
                    $cfgPath = APPPATH . 'config' . DIRECTORY_SEPARATOR . 'KafkaSet.php';
                    if (!file_exists($cfgPath)) {
                        throw new Exception("当前应用未进行Kafka配置[config/KafkaSet].", 1);
                    }
                    require_once $cfgPath;
                }

                static::$producerConfig = \Kafka\ProducerConfig::getInstance();
                //    Topic元数据刷新间隔（以毫秒为单位）,错误时元数据会自动刷新并连接,使用-1禁用间隔刷新。
                static::$producerConfig->setMetadataRefreshIntervalMs(10000);
                //  消息最大长度
                static::$producerConfig->setMessageMaxBytes(1000000000);
                //    设置Broker服务器列表
                static::$producerConfig->setMetadataBrokerList($kafkaSet["BrokerHostPort"]);
                //    设置Broker节点版本
                static::$producerConfig->setBrokerVersion('0.10.2.1');
                //    设置消息确认模式 0,1,-1 ;  0 = 不向客户端发送任何响应/确认;1 = 只有Leader需要确认消息 ; -1 = 全部代理将阻塞，直到所有同步副本（ISR）或代理的in.sync.replicas设置提交了消息，然后再发送响应
                static::$producerConfig->setRequiredAck(1);
                //    设置是否使用异步生产消息
                static::$producerConfig->setIsAsyn(true);
                //    设置异步生成消息时执行生产消息请求的时间间隔
                static::$producerConfig->setProduceInterval(500);
                //  消费消息整体超时时间, 该值一定要大于 timeout 参数
                static::$producerConfig->setRequestTimeout(6000);
                //  生产消息请求超时时间
                static::$producerConfig->setTimeout(5000); //kafka 请求超时控制
            } catch (Exception $ex) {
                // log_message("ERROR", "init kafka config is error ." . PHP_EOL . $ex->getMessage() . PHP_EOL . $ex->getTraceAsString());
                throw new Exception("init kafka config is error .", 1);
            }
        }
    }

    /**
     * 发送同步消息。
     */
    public static function sendSync($topic, $msg, $key = null)
    {
        static::initProducerConfig();

        try {
            $producer = new \Kafka\Producer();
            $result = $producer->send(
                array(
                    array(
                        'topic' => $topic,
                        'value' => is_string($msg) ? $msg : json_encode($msg),
                        'key' => $key,
                    ),
                )
            );
            if ($result) {
                // log_message("INFO", "kafka sendSync is success . result: " . json_encode($result) . " topic: " . $topic . " msg: " . (is_string($msg) ? $msg : json_encode($msg)));
            } else {
                // log_message("ERROR", "kafka sendSync is error . errorInfo: " . json_encode($result));

            }
        } catch (Exception $ex) {
            file_put_contents(APPPATH . "logs/kafka_error_" . date('Y-m-d') . ".log", date('Y-m-d H:i:s') . " " . $ex->getMessage() . PHP_EOL . $ex->getTraceAsString() . PHP_EOL, FILE_APPEND);
            // log_message("ERROR", "kafka sendSync msg error ." . PHP_EOL . $ex->getMessage() . PHP_EOL . $ex->getTraceAsString());
            // throw new Exception("kafka sendSync msg error . topic: " . $topic . " msg:" . json_encode($msg) . PHP_EOL . $ex->getMessage() . PHP_EOL . $ex->getTraceAsString(), 1);
        }
    }

    /**
     * 发送异步消息。
     */
    public static function sendAsync($topic, $msg, $key = null)
    {
        static::initProducerConfig();

        try {
            $producer = new \Kafka\Producer(function () use ($topic, $msg, $key) {
                return array(
                    array(
                        'topic' => $topic,
                        'value' => is_string($msg) ? $msg : json_encode($msg),
                        'key' => $key, // ?? static::$configParam["key"],
                    ),
                );
            });
            $producer->success(function ($result) use ($topic, $msg, $key) {
                // log_message("INFO", "kafka sendAsync is success . result: " . json_encode($result) . " topic: " . $topic . " msg: " . (is_string($msg) ? $msg : json_encode($msg)));
            });
            $producer->error(function ($errorCode) use ($topic, $msg, $key) {
                file_put_contents(APPPATH . "logs/kafka_error_" . date('Y-m-d') . ".log", date('Y-m-d H:i:s') . " " . "topicName:" . $topic . " key:" . $key . " msg:" . $msg . " errorCode:" . json_encode($errorCode) . PHP_EOL, FILE_APPEND);
                // log_message("ERROR", "kafka sendAsync is error . errorCode: " . json_encode($errorCode));
            });
            $producer->send();
        } catch (Exception $ex) {
            file_put_contents(APPPATH . "logs/kafka_error_" . date('Y-m-d') . ".log", date('Y-m-d H:i:s') . " " . $ex->getMessage() . PHP_EOL . $ex->getTraceAsString() . PHP_EOL, FILE_APPEND);
            // log_message("ERROR", "kafka sendAsync msg error ." . PHP_EOL . $ex->getMessage() . PHP_EOL . $ex->getTraceAsString());
            // throw new Exception("kafka sendAsync msg error . topic: " . $topic . " msg:" . json_encode($msg) . $ex->getMessage(), 1);
        }
    }

    /**
     * 初始kafka 消费消息配置。
     * @return [type] [description]
     */
    protected static function initConsumerConfig(): void
    {
        if (empty(static::$consumerConfig)) {
            try {
                if (empty($kafkaSet)) {
                    $cfgPath = APPPATH . 'config' . DIRECTORY_SEPARATOR . 'KafkaSet.php';
                    if (!file_exists($cfgPath)) {
                        throw new Exception("当前应用未进行Kafka配置[config/KafkaSet].", 1);
                    }
                    require_once $cfgPath;
                }
                static::$consumerConfig = \Kafka\ConsumerConfig::getInstance();
                //    Topic元数据刷新间隔（以毫秒为单位）,错误时元数据会自动刷新并连接,使用-1禁用间隔刷新。
                static::$consumerConfig->setMetadataRefreshIntervalMs(10000);
                //  消息最大长度
                static::$producerConfig->setMessageMaxBytes(1000000000);
                //    设置Broker服务器列表
                static::$consumerConfig->setMetadataBrokerList($kafkaSet["BrokerHostPort"]);
                //    设置Broker节点版本
                static::$consumerConfig->setBrokerVersion('0.10.2.1');
                //  设置客户端组ID字符串。共享相同group.id的所有客户端都属于同一组
                static::$consumerConfig->setGroupId('MLS'); // 必填项。
                //  设置Topics
                static::$consumerConfig->setTopics(array('mlsTest'));
                //    设置异步生成消息时执行生产消息请求的时间间隔
                static::$producerConfig->setProduceInterval(500);
                //  消费消息整体超时时间, 该值一定要大于 timeout 参数
                static::$producerConfig->setRequestTimeout(6000);
                //  生产消息请求超时时间
                static::$producerConfig->setTimeout(5000); //kafka 请求超时控制
            } catch (Exception $ex) {
                // log_message("ERROR", "init kafka config is error ." . PHP_EOL . $ex->getMessage() . PHP_EOL . $ex->getTraceAsString());
                throw new Exception("init kafka config is error .", 1);
            }
        }
    }

    /**
     * 消费消息。
     * @return [type] [description]
     */
    public static function consumeMsg()
    {
        static::initConsumerConfig();

        $consumer = new \Kafka\Consumer();
        $consumer->start(function ($topic, $part, $message) {
            //  这里监听topic 队列；
            // log_message("INFO", ">>>>> consumeMsg data:    topic:" . json_encode($topic) . " part:" . json_encode($part) . " msg:" . json_encode($message));
        });
    }
}
