<?php
defined('BASEPATH') or exit('No direct script access allowed');
if (!class_exists("TestController")) {
    require_once APPPATH . 'core' . DIRECTORY_SEPARATOR . 'TestController.php';
}

class KafkaTest extends TestController
{
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * 异步消息发布测试。
     * @return [type] [description]
     */
    public function producerMsgTest()
    {
        $this->load->library("tools/msg/kafka/kafkaLib");

        $topic = "mlsTest";
        $msg = json_encode(array("aa" => 111, "bb" => true, "ccc" => "汉子", "ddd" => 1010101010, "eee" => "混合xxxx", "fff" => array("ggg" => 123, "hhh" => "ss ")));
        $key = null;
        KafkaLib::sendSync($topic, $msg, $key);
    }

    public function consumeMsgTest()
    {
        $this->load->library("tools/msg/kafka/kafkaLib");
        KafkaLib::consumeMsg();
    }

    public function functionTest()
    {
        // phpinfo();
        // try {
        //     $zkc = new \Zookeeper();
        //     $zkc->connect('172.0.71.54:2181');
        //     var_dump($zkc->get('/zookeeper'));
        // } catch (Exception $ex) {
        //     var_dump($ex->getMessage());
        // }
    }
}
